# Clique & Lucro

App de clique e ganhe com integração AdMob e sistema de saque via Pix.

## Como usar

- Clone este repositório
- Configure seu Firebase e AdMob
- Compile com Flutter ou via Codemagic